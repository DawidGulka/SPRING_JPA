package com.capgemini.wsb.fitnesstracker.user.internal;

import com.capgemini.wsb.fitnesstracker.user.api.User;
import com.capgemini.wsb.fitnesstracker.user.api.UserNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1/users")
@RequiredArgsConstructor
class UserController {

    private final UserServiceImpl userService;

    private final UserMapper userMapper;

    @GetMapping("/getusers")
    public List<UserDto> getAllUsers() {
        return userService.findAllUsers()
                          .stream()
                          .map(userMapper::toDto)
                          .toList();
    }

    @PostMapping("/saveUser")
    public User addUser(@RequestBody UserDto userDto) throws InterruptedException {

        // Demonstracja how to use @RequestBody
        System.out.println("User with e-mail: " + userDto.email() + "passed to the request");

        // TODO: saveUser with Service and return User
        User usertosave = userMapper.toEntity(userDto);
        return userService.createUser(usertosave);
    }
@GetMapping("/searchUser")
public UserDto searchuser(@RequestParam("id") Long id) throws UserNotFoundException {
    Optional<User> optionalUser = userService.getUser(id);
    if (optionalUser.isPresent()) {
        User rightuser = optionalUser.get();
        UserDto returneduser = userMapper.toDto(rightuser);
        return returneduser;
    }
    else {
        throw new UserNotFoundException(id);
    }
}
@DeleteMapping("/deleteUser")
public void deleteuser (@RequestParam("id") Long id) throws UserNotFoundException {
        Optional<User> optionalUser = userService.getUser(id);
                if (optionalUser.isPresent()) {
                    User userToDelete = optionalUser.get();
                     userService.deleteuser(userToDelete.getId());
                } else {
                    throw new UserNotFoundException(id);
                }
}
}